MYCONST = 2

print('Loaded "myMod4"!')

from . funcA import *
from . funcs import *

