MYCONST = 2

print('Loaded "myMod2"!')

