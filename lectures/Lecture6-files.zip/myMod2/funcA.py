def funcA(data1, data2):
	"""
	Function to print the two data given

	This function simply prints the two data given.

	:param data1: First data written
	:param data2: Second data written

	:return: Nothing
	"""
    
	print('My data is: "{}", "{}"'.format(data1, data2))


