"""
My own library for printing stuff!

Not much to say....
"""

WIDTH = 10

def funcA(dataA1, dataA2):
    """
    funcA: print two objects.

    :param dataA1: Any object that can be printed
    :param dataA2: Any object that can be printed
    """
    
    print('My data is: "{}", "{}"'.format(dataA1, dataA2))

def funcB():
    """funcB: indicate that task is done."""
    print('Task done: "{}"'.format(__name__))

if __name__ == '__main__':
    funcA("Testing", "funcA")
    funcB()
