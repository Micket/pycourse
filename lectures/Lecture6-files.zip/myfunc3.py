def myfunc3(parA, parB):
    """
    My very special function to sum 2 numbers.
    
    Parameters:
    -----------
    @param parA: First number to sum
    @param parB: Second number to sum
    
    @type paraA: float or int
    @type paraB: float or int

    Returns:
    --------
    @return: The sum of the given numbers
    @rtype: float or int
    """
    
    return parA + parB
