__author__ = 'thsv'


def myfunc(paraA, paraB):

    """
    My very special function to sum 2 numbers.

    :param paraA: First number to sum
    :param paraB: Second number to sum

    :type paraA: float or int
    :type paraB: float or int

    :return: Sum of the given numbers
    :rtype : float or int
    """
    return paraA + paraB

a = myfunc("12", 3)
b = "banana"
c = a + b