def myfunc2(parA: float or int, parB: float or int) -> float or int:
    """
    My very special function to sum 2 numbers.
    
    Parameters:
    -----------
    :param parA: First number to sum
    :param parB: Second number to sum
    
    Returns:
    --------
    :return: The sum of the given numbers
    """
    
    return parA + parB
