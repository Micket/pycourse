MYCONST = 2

print('Loaded "myMod3"!')

from . funcA import *

