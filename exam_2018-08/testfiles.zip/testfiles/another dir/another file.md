The md file extension is used for MarkDown documents. The more you know!
